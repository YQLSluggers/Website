﻿Public Class YQLMasterPage
    Inherits System.Web.UI.MasterPage

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim thisURL As String = Request.Url.Segments(Request.Url.Segments.Count - 1)

        Select Case thisURL
            Case "Default", "Default.aspx"
                tabCamps.Attributes.Remove("active")
                tabMemberships.Attributes.Remove("active")
                tabOpen.Attributes.Remove("active")
                tabContact.Attributes.Remove("active")
                tabHome.Attributes.Add("class", "active")
            Case "Camps", "Camps.aspx"
                tabHome.Attributes.Remove("active")
                tabMemberships.Attributes.Remove("active")
                tabOpen.Attributes.Remove("active")
                tabContact.Attributes.Remove("active")
                tabCamps.Attributes.Add("class", "active")
            Case "Memberships", "Memberships.aspx"
                tabCamps.Attributes.Remove("active")
                tabHome.Attributes.Remove("active")
                tabOpen.Attributes.Remove("active")
                tabContact.Attributes.Remove("active")
                tabMemberships.Attributes.Add("class", "active")
            Case "PublicAccess", "PublicAccess.aspx"
                tabCamps.Attributes.Remove("active")
                tabMemberships.Attributes.Remove("active")
                tabHome.Attributes.Remove("active")
                tabContact.Attributes.Remove("active")
                tabOpen.Attributes.Add("class", "active")
            Case "ContactUS", "ContactUs.aspx"
                tabCamps.Attributes.Remove("active")
                tabMemberships.Attributes.Remove("active")
                tabHome.Attributes.Remove("active")
                tabOpen.Attributes.Remove("active")
                tabContact.Attributes.Add("class", "active")


        End Select


    End Sub

End Class