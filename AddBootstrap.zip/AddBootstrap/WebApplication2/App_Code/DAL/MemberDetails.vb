﻿Public Class MemberDetails

End Class
